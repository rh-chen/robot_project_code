#include <ros/ros.h>
#include "InuSensor.h"
#include "DepthStream.h"

#include <iostream>
#include <fstream>
#include <string>
#include <memory>
#include <unistd.h>

#include <nodelet/loader.h>



int main(int argc, char* argv[])
{
std::cout << __FILE__ << __LINE__ << std::endl;
    ros::init(argc, argv, "inuitive_ros_wrapper");

std::cout << __FILE__ << __LINE__ << std::endl;
    nodelet::Loader nodelet;

std::cout << __FILE__ << __LINE__ << std::endl;
    nodelet::M_string remap(ros::names::getRemappings());

std::cout << __FILE__ << __LINE__ << std::endl;
    nodelet::V_string nargv;

std::cout << __FILE__ << __LINE__ << std::endl;
    nodelet.load(ros::this_node::getName(),
            "inuitive_ros_wrapper/InuitiveRosWrapperNodelet",
            remap, nargv);
std::cout << __FILE__ << __LINE__ << std::endl;
    ros::spin();

    return 0;
}
